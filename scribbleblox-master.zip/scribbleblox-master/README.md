# ScribbleBlox

Based on [Scratch](https://scratch.mit.edu/) by the Lifelong Kindergarten group at MIT, ScribbleBlox is a modification of Scratch that will add more features and blocks.

ScribbleBlocks is under the GNU General Public License version 3 at [http://www.gnu.org/licenses/gpl-3.0.txt](http://www.gnu.org/licenses/gpl-3.0.txt).
It is currently under development by Jonathan50 ([scratch](https://scratch.mit.edu/users/Jonathan50/)|[github](https://github.com/Jonathan50/)).

[https://scratch.mit.edu/discuss/topic/39898/](http://scratch.mit.edu/discuss/topic/39898/)

Thanks ST!
